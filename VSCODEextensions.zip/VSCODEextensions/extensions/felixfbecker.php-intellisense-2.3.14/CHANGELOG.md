# See [GitHub releases](https://github.com/felixfbecker/vscode-php-intellisense/releases)
