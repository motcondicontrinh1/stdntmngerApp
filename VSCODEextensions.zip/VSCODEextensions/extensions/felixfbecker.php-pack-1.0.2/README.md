
# PHP Extension Pack

Includes the most important extensions to get you started with PHP development in Visual Studio Code.

|              |         |
|--------------|---------|
| Debugger     | [![vs marketplace](https://img.shields.io/vscode-marketplace/v/felixfbecker.php-debug.svg?label=vs%20marketplace)](https://marketplace.visualstudio.com/items?itemName=felixfbecker.php-debug) [![downloads](https://img.shields.io/vscode-marketplace/d/felixfbecker.php-debug.svg)](https://marketplace.visualstudio.com/items?itemName=felixfbecker.php-debug) [![rating](https://img.shields.io/vscode-marketplace/r/felixfbecker.php-debug.svg)](https://marketplace.visualstudio.com/items?itemName=felixfbecker.php-debug) |
| IntelliSense | [![vs marketplace](https://img.shields.io/vscode-marketplace/v/felixfbecker.php-intellisense.svg?label=vs%20marketplace)](https://marketplace.visualstudio.com/items?itemName=felixfbecker.php-intellisense) [![downloads](https://img.shields.io/vscode-marketplace/d/felixfbecker.php-intellisense.svg)](https://marketplace.visualstudio.com/items?itemName=felixfbecker.php-intellisense) [![rating](https://img.shields.io/vscode-marketplace/r/felixfbecker.php-intellisense.svg)](https://marketplace.visualstudio.com/items?itemName=felixfbecker.php-intellisense) |
