<html>
   <head>
   </head>
   <body>
      <h1 class="test common" id="testID common">heading</h1>
      <div class="container">
      <!-- comment -->
        <span id="test-2" />
      </div>
   </body>
</html>